<?php


$description = $_POST["description"];
$prix = $_POST["prix"];
$quantite = $_POST["quantite"];
$Image=$_POST["image"];



$database = "piscine";

$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);


if ($db_found) {

	$sql=" SELECT * FROM panier WHERE Description='$description'";
	$result = mysqli_query($db_handle, $sql);

if(mysqli_num_rows($result) == 0)
{
	$sql = "INSERT INTO panier VALUES(0,'$description','$prix',1,'$Image')";
	$result = mysqli_query($db_handle, $sql);
	echo "Ajouté au panier";
}

else
{
	$sql ="UPDATE panier Set Quantite=Quantite+1 WHERE Description='$description'";
	$result = mysqli_query($db_handle, $sql);
	echo "Ajouté au panier";
}

}



else {
 echo "Database not found";
}//end else
//fermer la connection
mysqli_close($db_handle);

?>
