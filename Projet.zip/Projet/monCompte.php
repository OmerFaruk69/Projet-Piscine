<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>

		<form method="post" action="traitementmonCompte.php">
		<table>
			
					
			<tr>
				<td> Nom:</td>
			</tr>
			<tr>
				<td>
					<input type="text" name="nom" >
				</td>		
			</tr>
			<tr>
				<td>
					Prenom:
				</td>
			</tr>
			<tr>
				<td>
					<input type="text" name="prenom">
				</td>
			</tr>
			<tr>
				<td>
					Adresse:
				</td>
			</tr>
			<tr>
				<td>
					<input type="text" name="prenom">
				</td>
			</tr>
			<tr>
				<td>
					Email:
				</td>
			</tr>
			<tr>
				<td>
					<input type="text" name="prenom">
				</td>
			</tr>
			<tr>
				<td>
					Prenom:
				</td>
			</tr>
			<tr>
				<td>
					<input type="text" name="prenom">
				</td>
			</tr>


			<tr>
				<td>
					<input type="submit" name="valider" value="Valider">
				</td>
			</tr>

			

		</table>
	</form>

</body>
</html>