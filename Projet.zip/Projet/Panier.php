<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		
	</title>
</head>
<body>

<?php

$database = "piscine";

$db_handle = mysqli_connect('localhost', 'root', '' );
$db_found = mysqli_select_db($db_handle, $database);

if ($db_found) {
 $sql = "SELECT * FROM panier";
 $result = mysqli_query($db_handle, $sql);
 while ($data = mysqli_fetch_assoc($result))  {

 echo " Description: " . $data['Description'] . '<br>';
 echo " Prix: " . $data['Prix'] . '€<br>';
 echo " Quantite: " . $data['Quantite'] .'<br>';
 echo('<img class="image" src="' . $data['Image'] .'" /  <br/> </br>');

 
 }//end while

$sql ="SELECT  Sum(Quantite*Prix) as 'total' From Panier";
$result = mysqli_query($db_handle, $sql); 
$data = mysqli_fetch_assoc($result);
echo "Sous total : ". $data['total'].' €<br>';
}

?>
<a href="passerCommande.html"><button> Passer à la commande</button> </a>


<?
else {
 echo "Database not found";
}//end else
//fermer la connection
mysqli_close($db_handle);
?>


</body>
</html>

