<?php
$NumeroCarte = isset($_POST["numeroCarte"])?$_POST["numeroCarte"] : "";
$NomCarte = isset($_POST["nomCarte"])?$_POST["nomCarte"] : "";
$DateExpiration = isset($_POST["dateExpiration"])?$_POST["dateExpiration"] : "";
$CodeSecurite= isset($_POST["codeSecurite"])?$_POST["codeSecurite"] : "";
 $erreur = "";

if($NumeroCarte == "") {$erreur .= " Le champ Numero de Carte est vide. <br>";}
if($NomCarte == "") {$erreur .= " Le champ Nom de Carte est vide. <br>";}
if($DateExpiration == "") {$erreur .= " Le champ date Expiration est vide. <br>";}
if($CodeSecurite== "") {$erreur .= " Le champ Code de Securite est vide. <br>";}
		





 if ($erreur != "") {
 echo "Erreur : <br> $erreur";
 }


$database = "piscine";
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);


 //si le BDD existe, faire le traitement
if ($db_found) {


if($erreur=="")
{
	$sql ="SELECT * FROM acheteur WHERE NumeroCarte='$NumeroCarte' AND NomCarte='$NomCarte' And DateExpiration='$DateExpiration' AND CodeSecurite='$CodeSecurite'";
	 $result = mysqli_query($db_handle, $sql);

	 if(mysqli_num_rows($result) == 0)
	{
		echo "Erreur, veuillez réessayer";
	}
	else{
		echo "Paiement Validé";
		$db_found = mysqli_select_db($db_handle, $database);
		$sql = "DELETE FROM Panier";
		$result = mysqli_query($db_handle, $sql);


	}

}
}


else {
 echo "Database not found";
}

mysqli_close($db_handle);
?>

